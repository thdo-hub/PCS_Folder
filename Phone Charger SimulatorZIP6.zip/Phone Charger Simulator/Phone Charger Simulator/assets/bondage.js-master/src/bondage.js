'use strict';

module.exports = require('./runner.js');
